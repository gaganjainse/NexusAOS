# Document: Job Matrix
Version 1.0 (Golden Master)


## Overview
**Branch:** Core
**Level:** Individual Contributor
**Superior:** None


## Purpose
To ensure that every role has a clear supervisor, a defined purpose, and that there are no **"Unsupervised Nodes"** or **"Administrative Bloat"** within the organization.


## Responsibilities
- ### 1. Ultimate Oversight (User Command Layer)
- | Branch | Department | Role | Superior | Primary Ownership |
- | :--- | :--- | :--- | :--- | :--- |
- | **HQ** | **NCC** | **Nexus Omni-Lead** | **THE USER** | **Global Sync & User Reporting** |
- | **HQ** | **NCC** | **[Nexus Orchestrator](../../roles/hq/ncc/nexus_orchestrator_agent.md)** | **Omni-Lead** | **Real-Time Event Loop & Directive Routing** |
- | **HQ** | **NCC** | **[Nexus Input Parser](../../roles/hq/ncc/nexus_input_parser_agent.md)** | **Orchestrator** | **Intent Translation & Directive Formatting** |
- | **HQ** | **NCC** | **[Oracle Agent (OIA)](../../roles/hq/ncc/oracle_interface_agent.md)** | **Orchestrator** | **NCC Interface & Directive Verification** |
- | **HQ** | **NCC** | **Learning Synth Agent** | **Omni-Lead** | **Intelligence Summarization** |
- | **HQ** | **NCC** | **System Health Sup.** | **Omni-Lead** | **Infrastructure Integrity** |


## Deliverables
None


## Reporting & Supervision
- **Reports to:** None
- **Supervises:** None


## Approval Authority
None


---


**Navigation:** [Global Dashboard](./corporate_os_handbook.md) | [Site Map](./site_map.md)
